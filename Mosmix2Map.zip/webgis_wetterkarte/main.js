// Main-Datei

//bei eigenen dateien punkt davor bei installierten dateien nicht

// CSS
import './style.css'; 
import './css/fontawesome/css/all.css';
import './css/button.css';
import './css/layer.css';
import './css/wetter.css';
import './css/zeiten.css';
import './css/modal.css';
import './css/toern.css';
import './css/route.css';


// JS
import './js/map';              
import './js/route';          
import './js/layerOptions'
import './js/wetterOptions'
import './js/wetterZeitpunkte'
import './js/toernOptions'
import './js/routeOptions'
import './js/login'
import './js/routes_table'
